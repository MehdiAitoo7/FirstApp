package com.example.firstapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText editTextAmount=findViewById(R.id.editTextAmount);
        Button buttonCompute=findViewById(R.id.buttonCompute);
        TextView textViewResult=findViewById(R.id.textViewResults);
        ListView listViewResult=findViewById(R.id.listViewResults);
        List<String> data=new ArrayList<>();
        ArrayAdapter<String> stringArrayAdapter=new
                ArrayAdapter<>(this,android.R.layout.simple_list_item_1,data);
        listViewResult.setAdapter(stringArrayAdapter);


        buttonCompute.setOnClickListener(new View.OnClickListener() {

            double amount1=1;
            double amount2=1;
            double result;
            @Override
            public void onClick(View v) {

            double amount = Double.parseDouble(editTextAmount.getText().toString());

                if(amount1>1){
                     result= amount2 * amount;
                }else{
                    result = amount;
                }

                textViewResult.setText(String.valueOf(result));
                data.add(amount+" * "+amount2+" = "+result);
                stringArrayAdapter.notifyDataSetChanged();
                editTextAmount.setText("");
                amount2=amount;
                amount1++;

            }
        });

    }
}